import asyncio
from bleak import BleakClient

DEVICE_ADDRESS = "B660B8F4-732E-E952-2E79-959BEE6B7B4F"  # Your CooSpo H6M address
HEART_RATE_CHARACTERISTIC_UUID = "00002a37-0000-1000-8000-00805f9b34fb"  # Standard HR characteristic

async def read_heart_rate():
    async with BleakClient(DEVICE_ADDRESS) as client:
        if await client.is_connected():
            print(f"Connected to {DEVICE_ADDRESS}")

            def notification_handler(sender, data):
                heart_rate = data[1]  # Extract HR from data packet
                print(f"Heart Rate: {heart_rate} BPM")

            await client.start_notify(HEART_RATE_CHARACTERISTIC_UUID, notification_handler)

            try:
                while True:  # Keep running indefinitely
                    await asyncio.sleep(1)  # Prevents CPU overuse
            except KeyboardInterrupt:
                print("\nStopping heart rate monitor...")
                await client.stop_notify(HEART_RATE_CHARACTERISTIC_UUID)

asyncio.run(read_heart_rate())
