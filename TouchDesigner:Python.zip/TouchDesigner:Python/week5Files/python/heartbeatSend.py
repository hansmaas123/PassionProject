import asyncio
from bleak import BleakClient
from pythonosc.udp_client import SimpleUDPClient

DEVICE_ADDRESS = "B660B8F4-732E-E952-2E79-959BEE6B7B4F"  
HEART_RATE_CHARACTERISTIC_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

# OSC Settings (TouchDesigner defaults to port 8000)
OSC_IP = "127.0.0.1"  # Localhost (change if sending to another machine)
OSC_PORT = 8000       # Default TouchDesigner OSC In port
osc_client = SimpleUDPClient(OSC_IP, OSC_PORT)  # Create OSC client

async def read_heart_rate():
    async with BleakClient(DEVICE_ADDRESS) as client:
        if await client.is_connected():
            print(f"Connected to {DEVICE_ADDRESS}")

            def notification_handler(sender, data):
                heart_rate = data[1]  # Extract HR value
                print(f"Heart Rate: {heart_rate} BPM")

                # Send Heart Rate to TouchDesigner via OSC
                osc_client.send_message("/heart_rate", heart_rate)

            await client.start_notify(HEART_RATE_CHARACTERISTIC_UUID, notification_handler)

            try:
                while True:
                    await asyncio.sleep(1)  # Keep the script running
            except KeyboardInterrupt:
                print("\nStopping heart rate monitor...")
                await client.stop_notify(HEART_RATE_CHARACTERISTIC_UUID)

asyncio.run(read_heart_rate())
